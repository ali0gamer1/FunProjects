# FPTIDEWTOAOA

Fun projects that i do enjoy writing them over and over again.
