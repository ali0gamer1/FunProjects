# Shunting yard calculator

In this calculator I have used Shunting-yard algorithm to convert math expressions (Infix notation) to RPN then wrote a parser for that.
